# Program Name: Delete a Dictionary Item
# Objective: Remove a key-value pair from a dictionary.
# Author Name: Aryan Godhankar

student = {
    "name": "Aryan Godhankar",
    "age": 18,
    "course": "Python",
    "city": "Amravati",
    "phone": "9876543210"
}

key = input("Enter key to remove: ")

if key in student:
    del student[key]
    print("Updated Dictionary:")
    print(student)
else:
    print("Key not found.")
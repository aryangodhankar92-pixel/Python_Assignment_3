# Program Name: Check Subset
# Objective: Check whether Set A is a subset of Set B.
# Author Name: Aryan Godhankar

set_a = {2, 5}
set_b = {1, 2, 3, 4, 5}

if set_a.issubset(set_b):
    print("Set A is a subset of Set B.")
else:
    print("Set A is not a subset of Set B.") 
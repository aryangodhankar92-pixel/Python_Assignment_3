# Program Name: Check Whether a Key Exists
# Objective: Check whether a particular key exists in a dictionary.
# Author Name: Aryan Godhankar

student = {
    "name": "Aryan Godhankar",
    "age": 18,
    "course": "Python"
}

key = input("Enter key: ")

if key in student:
    print("Key '" + key + "' exists in the dictionary.")
else:
    print("Key '" + key + "' does not exist in the dictionary.")
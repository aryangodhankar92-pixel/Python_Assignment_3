# Program Name: Add and Remove Elements
# Objective: Add a new number to a set, remove another number, and display the final set.
# Author Name: Aryan Godhankar

numbers = {10, 20, 30, 40, 50}

print("Original Set:", numbers)

add_num = int(input("Enter number to add: "))
numbers.add(add_num)

remove_num = int(input("Enter number to remove: "))
numbers.discard(remove_num)

print("Final Set:", numbers)
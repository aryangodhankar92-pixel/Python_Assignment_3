# Program Name: Add Two Numbers Using Function
# Objective: Create a function that accepts two numbers and returns their sum.
# Author Name: Aryan Godhankar

def add(a, b):
    return a + b

first = int(input("Enter first number: "))
second = int(input("Enter second number: "))

result = add(first, second)

print("Sum =", result)
# Program Name: Add a New Key-Value Pair
# Objective: Add a new key-value pair to an existing dictionary.
# Author Name: Aryan Godhankar

student = {
    "name": "Aryan Godhankar",
    "age": 18
}

phone = input("Enter phone number: ")

student["phone"] = phone

print("Updated Dictionary:")
print(student)
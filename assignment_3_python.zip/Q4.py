# Program Name: Union of Two Sets
# Objective: Create two sets and find their union.
# Author Name: Aryan Godhankar

set_a = {1, 2, 3, 4}
set_b = {3, 4, 5, 6}

print("Set A:", set_a)
print("Set B:", set_b)

union = set_a.union(set_b)

print("Union:", union)
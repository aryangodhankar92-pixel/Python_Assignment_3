# Program Name: Set Operations
# Objective: Demonstrate Union, Intersection, Difference and Symmetric Difference.
# Author Name: Aryan Godhankar

set_a = {1, 2, 3, 4}
set_b = {3, 4, 5, 6}

print("Set A:", set_a)
print("Set B:", set_b)

print("Union:", set_a | set_b)

print("Intersection:", set_a & set_b)

print("A - B:", set_a - set_b)

print("Symmetric Difference:", set_a ^ set_b)
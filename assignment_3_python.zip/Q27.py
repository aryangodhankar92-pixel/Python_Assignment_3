# Program Name: Function to Calculate Area
# Objective: Calculate the area of circle, rectangle and square using functions.
# Author Name: Aryan Godhankar

def circle_area(radius):
    return 3.14 * radius * radius


def rectangle_area(length, breadth):
    return length * breadth


def square_area(side):
    return side * side


radius = float(input("Enter radius: "))
print("Area of Circle =", circle_area(radius))

length = float(input("Enter length: "))
breadth = float(input("Enter breadth: "))
print("Area of Rectangle =", rectangle_area(length, breadth))

side = float(input("Enter side: "))
print("Area of Square =", square_area(side))
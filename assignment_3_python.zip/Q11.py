# Program Name: Create and Display a Dictionary
# Objective: Create a dictionary containing basic information about a student.
# Author Name: Aryan Godhankar

student = {
    "name": "Aryan Godhankar",
    "age": 18,
    "course": "Python",
    "city": "Amravati"
}

print("Student Details:")
print(student)
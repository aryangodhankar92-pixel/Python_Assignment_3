# Program Name: Student Marks Dictionary
# Objective: Store marks of different subjects and calculate total marks.
# Author Name: Aryan Godhankar

marks = {
    "Python": 85,
    "Maths": 78,
    "Database": 82,
    "Computer Networks": 75
}

print("Python:", marks["Python"])
print("Maths:", marks["Maths"])
print("Database:", marks["Database"])
print("Computer Networks:", marks["Computer Networks"])

total_marks = sum(marks.values())

print("Total Marks:", total_marks)
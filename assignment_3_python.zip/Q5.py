# Program Name: Intersection of Two Sets
# Objective: Find the common elements between two sets.
# Author Name: Aryan Godhankar

set_a = {10, 20, 30, 40}
set_b = {30, 40, 50, 60}

print("Set A:", set_a)
print("Set B:", set_b)

common_elements = set_a.intersection(set_b)

print("Common Elements:", common_elements)
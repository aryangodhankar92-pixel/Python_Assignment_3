# Program Name: Check Element in Set
# Objective: Check whether a particular element exists in a set.
# Author Name: Aryan Godhankar

numbers = {10, 20, 30, 40, 50}

print("Set:", numbers)

number = int(input("Enter number to search: "))

if number in numbers:
    print(number, "is present in the set.")
else:
    print(number, "is not present in the set.")
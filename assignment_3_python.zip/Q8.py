# Program Name: Find Number of Unique Elements
# Objective: Find the number of unique elements in a collection.
# Author Name: Aryan Godhankar

numbers = input("Enter numbers: ").split()

unique_numbers = set(map(int, numbers))

print("Number of Unique Elements:", len(unique_numbers))
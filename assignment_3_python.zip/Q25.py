# Program Name: Find Largest of Three Numbers
# Objective: Create a function that accepts three numbers and returns the largest number.
# Author Name: Aryan Godhankar

def largest(a, b, c):
    if a >= b and a >= c:
        return a
    elif b >= a and b >= c:
        return b
    else:
        return c


num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
num3 = int(input("Enter third number: "))

result = largest(num1, num2, num3)

print("Largest Number =", result)
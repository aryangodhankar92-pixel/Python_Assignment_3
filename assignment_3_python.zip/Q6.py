# Program Name: Difference Between Sets
# Objective: Find the elements that are present in Set A but not in Set B.
# Author Name: Aryan Godhankar

set_a = {1, 2, 3, 4, 5}
set_b = {4, 5, 6, 7}

print("Set A:", set_a)
print("Set B:", set_b)

difference = set_a - set_b

print("Difference:", difference)
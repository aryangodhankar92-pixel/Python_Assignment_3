# Program Name: Count Frequency of Words
# Objective: Count how many times each word appears in a sentence.
# Author Name: Aryan Godhankar

sentence = input("Enter sentence: ")

words = sentence.lower().split()

frequency = {}

for word in words:
    frequency[word] = frequency.get(word, 0) + 1

print(frequency)
# Program Name: Create a Simple Function
# Objective: Create a function that displays a welcome message.
# Author Name: Aryan Godhankar

def welcome():
    print("Welcome to Python Programming!")

welcome()
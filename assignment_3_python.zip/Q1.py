# Program Name: Create and Display a Set
# Objective: Accept 5 numbers, store them in a set, and display the set.
# Author Name: Aryan Godhankar

numbers = input("Enter 5 numbers: ").split()

numbers = set(map(int, numbers))

print("Set:", numbers)

# self practice
# Objective: Accept 5 percentage values, store them in a set, and display the set

per = input("Enter 5 percentage: ").split()
per = set(map(float, per))

print("Set:", per)
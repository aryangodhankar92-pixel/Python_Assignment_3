# Program Name: Function to Check Prime Number
# Objective: Check whether a given number is a prime number.
# Author Name: Aryan Godhankar

def is_prime(number):

    if number <= 1:
        return False

    for i in range(2, number):
        if number % i == 0:
            return False

    return True


num = int(input("Enter number: "))

if is_prime(num):
    print(num, "is a Prime Number.")
else:
    print(num, "is not a Prime Number.")
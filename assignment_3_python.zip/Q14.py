# Program Name: Update a Dictionary Value
# Objective: Update an existing value in a dictionary.
# Author Name: Aryan Godhankar

student = {
    "name": "Aryan Godhankar",
    "age": 18
}

print("Original Age:", student["age"])

student["age"] = 21

print("Updated Age:", student["age"])
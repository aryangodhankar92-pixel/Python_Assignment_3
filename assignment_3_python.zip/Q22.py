# Program Name: Function with Parameter
# Objective: Create a function that accepts a person's name and displays a greeting.
# Author Name: Aryan Godhankar

def greet(name):
    print("Hello", name + ", Welcome to Python!")

person_name = input("Enter your name: ")

greet(person_name)
# Program Name: Access Dictionary Values
# Objective: Access specific values from a dictionary using keys.
# Author Name: Aryan Godhankar

student = {
    "name": "Aryan Godhankar",
    "age": 18,
    "course": "Python",
    "city": "Amravati"
}

print("Name:", student["name"])
print("Age:", student["age"])
print("Course:", student["course"])
print("City:", student["city"])
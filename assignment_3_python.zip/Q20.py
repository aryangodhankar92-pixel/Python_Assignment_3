# Program Name: Dictionary Menu Program
# Objective: Perform add, update, delete, search and display operations on a dictionary.
# Author Name: Aryan Godhankar

data = {}

while True:
    print("\n1. Add Item")
    print("2. Update Item")
    print("3. Delete Item")
    print("4. Search Item")
    print("5. Display Items")
    print("6. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        key = input("Enter key: ")
        value = input("Enter value: ")
        data[key] = value
        print("Item added successfully.")

    elif choice == "2":
        key = input("Enter key to update: ")

        if key in data:
            value = input("Enter new value: ")
            data[key] = value
            print("Item updated successfully.")
        else:
            print("Key not found.")

    elif choice == "3":
        key = input("Enter key to delete: ")

        if key in data:
            del data[key]
            print("Item deleted successfully.")
        else:
            print("Key not found.")

    elif choice == "4":
        key = input("Enter key to search: ")

        if key in data:
            print("Value:", data[key])
        else:
            print("Key not found.")

    elif choice == "5":
        print("Dictionary Items:", data)

    elif choice == "6":
        print("Program ended.")
        break

    else:
        print("Invalid choice.")
# Program Name: Calculate Factorial Using Function
# Objective: Create a function to calculate the factorial of a number.
# Author Name: Aryan Godhankar

def factorial(number):
    fact = 1

    for i in range(1, number + 1):
        fact = fact * i

    return fact


num = int(input("Enter number: "))

result = factorial(num)

print("Factorial =", result)
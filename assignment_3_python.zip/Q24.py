# Program Name: Check Even or Odd Using Function
# Objective: Create a function that checks whether a number is even or odd.
# Author Name: Aryan Godhankar

def check_even_odd(number):
    if number % 2 == 0:
        return "Even"
    else:
        return "Odd"

number = int(input("Enter number: "))

result = check_even_odd(number)

print(number, "is", result + ".")
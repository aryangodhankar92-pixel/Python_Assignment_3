# Program Name: Student Result Using Functions
# Objective: Calculate total marks, percentage, grade and result using functions.
# Author Name: Aryan Godhankar

def calculate_total(marks):
    return sum(marks)


def calculate_percentage(total):
    return total / 5


def calculate_grade(percentage):
    if percentage >= 90:
        return "A"
    elif percentage >= 80:
        return "B"
    elif percentage >= 70:
        return "C"
    elif percentage >= 60:
        return "D"
    else:
        return "F"


def calculate_result(marks):
    for mark in marks:
        if mark < 35:
            return "Fail"

    return "Pass"


python = float(input("Enter marks for Python: "))
maths = float(input("Enter marks for Maths: "))
database = float(input("Enter marks for Database: "))
networks = float(input("Enter marks for Networks: "))
ai = float(input("Enter marks for AI: "))

marks = [python, maths, database, networks, ai]

total = calculate_total(marks)
percentage = calculate_percentage(total)
grade = calculate_grade(percentage)
result = calculate_result(marks)

print("Total Marks:", total)
print("Percentage:", percentage, "%")
print("Grade:", grade)
print("Result:", result)
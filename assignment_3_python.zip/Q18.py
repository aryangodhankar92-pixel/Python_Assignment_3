# Program Name: Find Highest Marks
# Objective: Find the student who has scored the highest marks.
# Author Name: Aryan Godhankar

students = {
    "Rahul": 78,
    "Amit": 92,
    "Priya": 85
}

highest_student = max(students, key=students.get)

highest_marks = students[highest_student]

print("Highest Marks:", highest_marks)
print("Student:", highest_student)
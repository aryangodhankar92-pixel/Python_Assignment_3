# Program Name: Remove Duplicate Values
# Objective: Accept 8 numbers, store them in a set, and display unique numbers.
# Author Name: Aryan Godhankar

numbers = input("Enter 8 numbers: ").split()

unique_numbers = set(map(int, numbers))

print("Unique Numbers:", unique_numbers)